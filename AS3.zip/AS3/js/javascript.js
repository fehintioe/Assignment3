document.addEventListener('DOMContentLoaded', function() {
    const addTodoButton = document.getElementById('add-todo');
    const todoInput = document.getElementById('new-todo');
    const todoList = document.getElementById('todo-list');

    addTodoButton.addEventListener('click', function() {
        const todoText = todoInput.value.trim();
        if (todoText !== '') {
            addTodoItem(todoText);
            todoInput.value = '';
        }
    });

    function addTodoItem(text) {
        const li = document.createElement('li');
        li.className = 'todo-item';

        const checkbox = document.createElement('input');
        checkbox.type = 'checkbox';
        checkbox.addEventListener('change', function() {
            if (this.checked) {
                li.classList.add('completed');
                todoList.appendChild(li); // Move to bottom
            } else {
                li.classList.remove('completed');
            }
        });

        const todoText = document.createElement('span');
        todoText.textContent = text;

        const deleteButton = document.createElement('button');
        deleteButton.textContent = 'Delete';
        deleteButton.addEventListener('click', function() {
            todoList.removeChild(li);
        });

        li.appendChild(checkbox);
        li.appendChild(todoText);
        li.appendChild(deleteButton);
        todoList.appendChild(li);
    }
});
